using Microsoft.Maui.Controls;
using Microsoft.Maui.Graphics;
using System;

namespace RPS;

public partial class MessagePage : ContentPage
{
	public MessagePage(string message, Color color, int user_choice, int cpu_choice)
	{
        Dictionary<int, string> data = new Dictionary<int, string>
        {
            {0, "rock.png" },
            {1, "paper.png" },
            {2, "scissor.png" }
        };

		InitializeComponent();

        MessageLabel.Text = message;

        Content.BackgroundColor = color;

        UserChoice.Source = data[user_choice];
        CpuChoice.Source = data[cpu_choice];

        var tapGestureRecognizer = new TapGestureRecognizer();
        tapGestureRecognizer.Tapped += async (s, e) => await Navigation.PopAsync();
        Content.GestureRecognizers.Add(tapGestureRecognizer);
    }
}