﻿using Microsoft.Maui.Controls;
using Microsoft.Maui.Graphics;
using System;

namespace RPS
{
    public partial class MainPage : ContentPage
    {
        int user = 0, tie = 0, cpu = 0;
        public MainPage()
        {
            InitializeComponent();

            Content.BackgroundColor = Color.FromHex("3d3c3c");
            
            TapGestureRecognizer rockTap = new TapGestureRecognizer();
            rockTap.Tapped += Emoji_Tapped;
            rockimg.GestureRecognizers.Add(rockTap);

            TapGestureRecognizer paperTap = new TapGestureRecognizer();
            paperTap.Tapped += Emoji_Tapped;
            paperimg.GestureRecognizers.Add(paperTap);

            TapGestureRecognizer scissorTap = new TapGestureRecognizer();
            scissorTap.Tapped += Emoji_Tapped;
            scissorimg.GestureRecognizers.Add(scissorTap);

        }

        [Obsolete]
        private async void Emoji_Tapped(object sender, EventArgs e)
        {

            
            int user_choice = 0 , cpu_choice;
            Random random = new Random();

            if(sender == rockimg)
            {
                user_choice = 0;
            }
            else if (sender == paperimg)
            {
                user_choice = 1;
            }
            else if (sender == scissorimg)
            {
                user_choice = 2;
            }

            cpu_choice = random.Next(0, 3);
            //test.Text = cpu_choice.ToString();

            if (cpu_choice == user_choice )
            {
                tie++;
                TieScore.Text = "TIED: " + tie;
                await Display_Message_Page("It's a tie!", Color.FromHex("FFB329"), user_choice, cpu_choice);
                return;
            }

            else if (user_choice == 0 && cpu_choice == 2)
            {
                user++;
                UserScore.Text = "YOU: " + user;
                await Display_Message_Page("You won!", Color.FromHex("54E06C"), user_choice, cpu_choice);
                return;
            }

            else if (user_choice == 1 && cpu_choice ==  0)
            {
                user++;
                UserScore.Text = "YOU: " + user;
                await Display_Message_Page("You won!", Color.FromHex("54E06C"), user_choice, cpu_choice);
                return;
            }

            else if (user_choice == 2 && cpu_choice == 1)
            {
                user++;
                UserScore.Text = "YOU: " + user;
                await Display_Message_Page("You won!", Color.FromHex("54E06C"), user_choice, cpu_choice);
                return;
            }
            
            else
            {
                cpu++;
                CpuScore.Text = "COMPUTER: " + cpu;
                await Display_Message_Page("Oops, you lost", Color.FromHex("FB8080"), user_choice, cpu_choice);
                return;
            }

            
        }

        private async Task Display_Message_Page(string message, Color color, int user_choice, int cpu_choice)
        {
            await Navigation.PushAsync(new MessagePage(message, color, user_choice, cpu_choice));
        }
        
    }

}
